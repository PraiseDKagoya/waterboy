# Waterboy
Field logger for GPS + water params -> KML export
Open in Android Studio, run on device. Exports to /Android/data/com.waterboy.app/files/waterboy_exports/
Share via any app to Drive, WhatsApp, etc.