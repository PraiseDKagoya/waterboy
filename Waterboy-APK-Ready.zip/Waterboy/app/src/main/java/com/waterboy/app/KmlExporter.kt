
package com.waterboy.app
import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
object KmlExporter {
    fun export(context: Context, samples: List<WaterSample>): File {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        val dateFile = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val sb = StringBuilder()
        sb.appendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
        sb.appendLine("<kml xmlns=\"http://www.opengis.net/kml/2.2\">")
        sb.appendLine("<Document>")
        sb.appendLine("<name>Waterboy - ${samples.size} samples - $dateFile</name>")
        sb.appendLine("<description>Collected with Waterboy</description>")
        sb.appendLine("<Style id=\"waterStyle\"><IconStyle><color>ff990B6E</color><scale>1.1</scale><Icon><href>http://maps.google.com/mapfiles/kml/shapes/water.png</href></Icon></IconStyle></Style>")
        sb.appendLine("<Schema name=\"Waterboy\" id=\"WaterboySchema\"><SimpleField name=\"ph\" type=\"float\"/><SimpleField name=\"temperature\" type=\"float\"/><SimpleField name=\"dissolvedOxygen\" type=\"float\"/><SimpleField name=\"turbidity\" type=\"float\"/><SimpleField name=\"conductivity\" type=\"float\"/><SimpleField name=\"depth\" type=\"float\"/><SimpleField name=\"notes\" type=\"string\"/></Schema>")
        for (s in samples) {
            sb.appendLine("<Placemark>")
            sb.appendLine("<name>${esc(s.siteName.ifBlank { "Sample-${s.id}" })}</name>")
            sb.appendLine("<styleUrl>#waterStyle</styleUrl>")
            sb.appendLine("<TimeStamp><when>${sdf.format(Date(s.timestamp))}</when></TimeStamp>")
            sb.appendLine("<ExtendedData><SchemaData schemaUrl=\"#WaterboySchema\">")
            fun add(n:String, v:Any?) { if(v!=null) sb.appendLine("<SimpleData name=\"$n\">${esc(v.toString())}</SimpleData>") }
            add("ph", s.ph); add("temperature", s.temperature); add("dissolvedOxygen", s.dissolvedOxygen); add("turbidity", s.turbidity); add("conductivity", s.conductivity); add("depth", s.depth); add("notes", s.notes)
            sb.appendLine("</SchemaData>")
            sb.appendLine("<Data name=\"ph\"><value>${s.ph ?: ""}</value></Data>")
            sb.appendLine("<Data name=\"temperature\"><value>${s.temperature ?: ""}</value></Data>")
            sb.appendLine("<Data name=\"dissolvedOxygen\"><value>${s.dissolvedOxygen ?: ""}</value></Data>")
            sb.appendLine("<Data name=\"turbidity\"><value>${s.turbidity ?: ""}</value></Data>")
            sb.appendLine("<Data name=\"conductivity\"><value>${s.conductivity ?: ""}</value></Data>")
            sb.appendLine("</ExtendedData>")
            sb.appendLine("<Point><coordinates>${s.longitude},${s.latitude},${s.altitude ?: 0}</coordinates></Point>")
            sb.appendLine("</Placemark>")
        }
        sb.appendLine("</Document></kml>")
        val dir = File(context.getExternalFilesDir(null), "waterboy_exports")
        dir.mkdirs()
        val file = File(dir, "Waterboy_$dateFile.kml")
        file.writeText(sb.toString())
        return file
    }
    private fun esc(s:String): String = s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
}
