
package com.waterboy.app
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.waterboy.app.databinding.ItemPointBinding
class SampleAdapter : RecyclerView.Adapter<SampleAdapter.VH>() {
    private var items: List<WaterSample> = emptyList()
    fun submit(list: List<WaterSample>) { items = list; notifyDataSetChanged() }
    inner class VH(val b: ItemPointBinding) : RecyclerView.ViewHolder(b.root)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH = VH(ItemPointBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(holder: VH, position: Int) {
        val s = items[position]
        holder.b.tvItemTitle.text = s.siteName
        holder.b.tvItemCoords.text = "%.5f, %.5f +/-%.1fm".format(s.latitude, s.longitude, s.accuracy ?: 0f)
        val params = buildList { s.ph?.let { add("pH $it") }; s.temperature?.let { add("${it}C") }; s.dissolvedOxygen?.let { add("DO ${it}") }; s.turbidity?.let { add("Turb ${it}") } }.joinToString(" - ").ifBlank { s.notes.ifBlank { "No params" } }
        holder.b.tvItemParams.text = params
    }
}
