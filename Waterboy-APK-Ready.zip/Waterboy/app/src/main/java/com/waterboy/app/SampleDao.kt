
package com.waterboy.app
import androidx.room.*
@Dao
interface SampleDao {
    @Query("SELECT * FROM samples ORDER BY timestamp DESC")
    suspend fun getAll(): List<WaterSample>
    @Insert
    suspend fun insert(sample: WaterSample): Long
    @Query("DELETE FROM samples")
    suspend fun clearAll()
}
