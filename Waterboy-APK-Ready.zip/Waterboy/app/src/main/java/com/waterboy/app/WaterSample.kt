
package com.waterboy.app
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "samples")
data class WaterSample(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val siteName: String,
    val latitude: Double,
    val longitude: Double,
    val altitude: Double?,
    val accuracy: Float?,
    val ph: Double?,
    val temperature: Double?,
    val dissolvedOxygen: Double?,
    val turbidity: Double?,
    val conductivity: Double?,
    val depth: Double?,
    val notes: String
)
