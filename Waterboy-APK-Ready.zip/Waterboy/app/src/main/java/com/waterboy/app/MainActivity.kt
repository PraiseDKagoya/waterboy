
package com.waterboy.app
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.os.Looper
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.location.*
import com.waterboy.app.databinding.ActivityMainBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var fused: FusedLocationProviderClient
    private lateinit var db: AppDatabase
    private var currentLocation: Location? = null
    private lateinit var adapter: SampleAdapter
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
        if (granted[Manifest.permission.ACCESS_FINE_LOCATION] == true) startLocationUpdates()
        else Toast.makeText(this, "Location permission needed", Toast.LENGTH_LONG).show()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        fused = LocationServices.getFusedLocationProviderClient(this)
        db = AppDatabase.get(this)
        adapter = SampleAdapter()
        binding.rvPoints.layoutManager = LinearLayoutManager(this)
        binding.rvPoints.adapter = adapter
        checkPerms()
        setupButtons()
        refreshList()
    }
    private fun checkPerms() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        if (fine != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        } else startLocationUpdates()
    }
    private fun startLocationUpdates() {
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 3000).build()
        try {
            fused.requestLocationUpdates(request, object : LocationCallback() {
                override fun onLocationResult(r: LocationResult) {
                    currentLocation = r.lastLocation
                    r.lastLocation?.let { loc ->
                        binding.tvLocation.text = "%.6f, %.6f".format(loc.latitude, loc.longitude) + if(loc.hasAltitude()) " Alt %.1fm".format(loc.altitude) else ""
                        binding.tvAccuracy.text = "Accuracy: +/-%.1f m - %s".format(loc.accuracy, SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()))
                        binding.btnCollect.isEnabled = true
                    }
                }
            }, Looper.getMainLooper())
        } catch (e: SecurityException) {}
    }
    private fun setupButtons() {
        binding.btnCollect.isEnabled = false
        binding.btnCollect.setOnClickListener { collect() }
        binding.btnExportKml.setOnClickListener { export() }
        binding.btnClear.setOnClickListener { lifecycleScope.launch { db.sampleDao().clearAll(); refreshList() } }
    }
    private fun collect() {
        val loc = currentLocation
        if (loc == null) { Toast.makeText(this, "No GPS fix yet", Toast.LENGTH_SHORT).show(); return }
        val site = binding.etSiteName.text?.toString()?.trim().orEmpty()
        if (site.isBlank()) { binding.etSiteName.error = "Required"; return }
        fun parse(v: com.google.android.material.textfield.TextInputEditText): Double? = v.text?.toString()?.toDoubleOrNull()
        val sample = WaterSample(siteName = site, latitude = loc.latitude, longitude = loc.longitude, altitude = if (loc.hasAltitude()) loc.altitude else null, accuracy = loc.accuracy, ph = parse(binding.etPH), temperature = parse(binding.etTemp), dissolvedOxygen = parse(binding.etDO), turbidity = parse(binding.etTurbidity), conductivity = parse(binding.etConductivity), depth = parse(binding.etDepth), notes = binding.etNotes.text?.toString()?.trim().orEmpty())
        lifecycleScope.launch {
            db.sampleDao().insert(sample)
            refreshList()
            Toast.makeText(this@MainActivity, "Collected: $site", Toast.LENGTH_LONG).show()
            val regex = Regex("(.*?)(\\d+)$")
            val m = regex.find(site)
            binding.etSiteName.setText(if (m != null) "${m.groupValues[1]}${m.groupValues[2].toInt()+1}" else "$site-2")
        }
    }
    private fun refreshList() { lifecycleScope.launch { val list = db.sampleDao().getAll(); adapter.submit(list); binding.btnExportKml.isEnabled = list.isNotEmpty(); binding.btnExportKml.text = if (list.isEmpty()) "Export KML" else "Export KML (${list.size})" } }
    private fun export() {
        lifecycleScope.launch {
            val list = db.sampleDao().getAll()
            if (list.isEmpty()) return@launch
            val file = KmlExporter.export(this@MainActivity, list)
            val uri: Uri = FileProvider.getUriForFile(this@MainActivity, "${packageName}.fileprovider", file)
            val share = Intent(Intent.ACTION_SEND).apply { type = "application/vnd.google-earth.kml+xml"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            startActivity(Intent.createChooser(share, "Share KML: ${file.name}"))
        }
    }
}
