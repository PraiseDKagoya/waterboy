
# How to get Waterboy APK - 3 options

## Option 1: Android Studio (easiest, 2 mins)
1. Open Waterboy folder in Android Studio
2. Wait for Gradle sync
3. Menu: Build > Build APK(s) > Build Debug APK
4. APK location: app/build/outputs/apk/debug/app-debug.apk
5. Copy to phone, allow "Install from unknown sources", install.

## Option 2: One command line
```bash
cd Waterboy
./gradlew assembleDebug
# APK at app/build/outputs/apk/debug/app-debug.apk
```

## Option 3: Auto-build with GitHub (no Android Studio needed)
1. Create new GitHub repo, push this folder
2. Go to Actions tab -> "Build Waterboy APK" -> Run workflow
3. Download artifact "Waterboy-debug-apk"
4. That's your installable APK.

## Installing on phone
- Enable Developer Options: Settings > About phone > tap Build number 7 times
- Or simply: Settings > Security > Allow install unknown apps
- Transfer APK via WhatsApp/Drive/USB and tap to install.

## What the APK does
- No internet needed except for maps
- GPS: auto, high accuracy
- Exports KML to: /storage/emulated/0/Android/data/com.waterboy.app/files/waterboy_exports/
- Share button sends KML to any app.
