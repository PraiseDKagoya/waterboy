
# FIX: Can't see auto-builds? Do this

The previous zip was missing gradle-wrapper.jar so GitHub failed.

NEW ZIP HAS 2 WORKFLOWS THAT FIX IT:

### Steps - do exactly:

1. Delete old repo OR delete old .github folder in your repo
2. Upload the NEW Waterboy-APK-Ready.zip contents
3. Go to GitHub -> Your Repo -> Settings -> Actions -> General
   - Enable "Allow all actions"
   - Check "Read and write permissions" -> Save

4. Go to Actions tab
   - If you see "Workflows aren't being run" -> Click "I understand... Enable"
   - You should now see 2 workflows:
     * Build Waterboy APK
     * Build APK Simple

5. Click "Build APK Simple" -> Click "Run workflow" -> Green "Run workflow" button
   - Wait 3-4 mins, it will build
   - When green check appears, click it -> Scroll down to Artifacts -> Download "Waterboy-debug"

6. If that still fails, click on the failed run and screenshot the error log for me.

### Why it failed before:
- Old gradlew was fake, no gradle-wrapper.jar
- New version installs gradle and creates wrapper on GitHub itself.

### Still stuck?
Push this file structure exactly:
```
Waterboy/
  .github/workflows/build-apk-simple.yml
  app/
  build.gradle.kts
  settings.gradle.kts
  gradlew
  gradle/wrapper/gradle-wrapper.properties
```

Do NOT zip inside zip - upload the FOLDER contents to root of repo.
